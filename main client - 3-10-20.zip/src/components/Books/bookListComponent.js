import React, { Component } from "react";
// import BookDataService from "../services/book.service";
import { getUserName } from "../../services/auth-header";
import axios from 'axios';
import { Link } from 'react-router-dom';
export default class BooksList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            books: [],
            cart: []
        };

        this.addToCartHandler = this.addToCartHandler.bind(this);

        // this.cart = this.cart.bind(this);
    }

    //New from old one

    addC() {
        console.log("Cart");
    }

    componentDidMount() {
        axios.get("http://localhost:8080/api/books/g").then((res) => {
            this.setState({
                books: res.data
            });
            console.log(res.data);
        })
            .catch(e => {
                console.log(e);
            });
    }

    addToCartHandler = (id) => {
        console.log(id);
        axios.post(
            `http://localhost:8080/cart/addBook?id=${id}&user=${getUserName()}`
        ).then((res) => {
            console.log(res.data.message);
            if (res.data.message === true) {
                this.props.history.push(`/cart`);
            } else {
                this.setState({
                    message: `Unable to add to cart please try again later`,
                });
                alert(this.state.message);
            }
        });
    };


    render() {
        console.log(this.state);
        return (

            <div className="container">
                <div className="row">
                    {this.state.books.map((book, index) => {
                        return (

                            <div className="col-md-6">
                                <div className="card">
                                    {/* <img src={carousel1} className="card-img-top" alt="..." /> */}
                                    <div className="card-body" key={index}>
                                        <p className="card-text "><strong>Book Id:</strong>&nbsp;{book.id}</p>
                                        <p className="card-text "><strong>Book Title:</strong>&nbsp;{book.title}</p>
                                        <p className="card-text"><strong>Book Category:</strong>&nbsp;{book.category}</p>
                                        <p className="card-text"><strong>Book Price:</strong>&nbsp;{book.price}</p>
                                        <p className="card-text"><strong>Book Author:</strong>&nbsp;{book.author}</p>

                                        <p className="card-text"><strong>Book Publisher:</strong>&nbsp;{book.publisher}</p>
                                        <p className="card-text"><strong>Book Description:</strong>&nbsp;{book.description}</p>
                                        <a class="btn btn-danger">Buy</a> &nbsp;
                                        {/* <a class="btn btn-success float-right">Add to Cart</a> */}
                                        <button className="btn btn-warning" onClick={() => this.addToCartHandler(book.id)}>Add to cart</button>
                                        {/* <Link to="/cart" className="cart">Cart</Link> */}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        )
    }
}




